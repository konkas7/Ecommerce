﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecommerce
{
    class Program
    {
        static void Main(string[] args)
        {
            Carrello carrellino = new Carrello("1");
            Prodotto prodotto= new Prodotto("tdec23", "Balenciaga Tee","Balenciaga", "Bellissima maglietta verde acqua (l'acqua è azzurra)")
        }
    }
}
