﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ecommerce
{
    public partial class AGGIUNTA : Form
    {
        Prodotto prodotto = new Prodotto();
        public AGGIUNTA()
        {
            InitializeComponent();
        }

        private void AGGIUNTA_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            prodotto.Descrizione = textBox4.Text;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            prodotto.Id = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            prodotto.Nome = textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            prodotto.Produttore = textBox3.Text;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            prodotto.setPrezzo = float.Parse(textBox5.Text);
        }
    }
}
